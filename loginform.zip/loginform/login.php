
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <center> <h style="font-size:25;font-family:Georgia;font-weight:bold;padding-top:20px 200px;">Login Page</h></center>
</head>
<body>
   <form method="POST" action="conn.php" >
    <div class="container">
    <center>
       <div class="form">
            
            <label style="color:#000000;font-weight:bold;font-size:18px;font-family:Georgia;"for="pname">UserName:</label>
            <input style="color:#000000;font-weight:500;font-size:16px;font-family:Georgia;" type="text" name="UserName"/><br>
        </div>
        <div class="form">
            <label style="color:#000000;font-weight:bold;font-size:18px;font-family:Georgia;"for="pemail">Password:</label>
            <input style="color:#000000;font-weight:500;font-size:16px;font-family:Georgia;"type="password" name="Password"><br>
        </div>
       <input type="submit"  value="Login" class="btn-login"/ ><br>
    </center>
</form>
</div>
    
</body>
</html>
