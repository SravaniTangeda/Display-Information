<?php
  $host="localhost";
$user="root";
$password=" ";
$db="login_database";
$conn=mysqli_connect($host,$user,$password);
mysqli_select_db($conn,$db);
   if(isset($_POST['UserName']))
   {
     $uname=$_POST['UserName'];
     $password=$_POST['Password'];
     $sql="select * from info where UserName='".$uname."'AND Password='".$password."' limit 1";
     $result=mysqli_query($conn,$sql);
     if(mysqli_num_rows($result)==1)
     {
        header("location:succ.html");
         exit();
     }
     else{
           echo " Incorrect Login Details";
          exit();
    }
     
 }
?>